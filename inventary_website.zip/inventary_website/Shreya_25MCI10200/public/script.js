document.addEventListener("DOMContentLoaded", () => {
    const menuButtons = document.querySelectorAll(".sidebar .menu-btn");
    const modules = document.querySelectorAll(".module-view");

    menuButtons.forEach(button => {
        button.addEventListener("click", () => {
            // 1. Sabhi buttons se active state aur custom inline color styles hatayein
            menuButtons.forEach(btn => {
                btn.classList.remove("active");
                btn.style.background = "transparent";
                btn.style.color = "#94a3b8";
                btn.style.borderLeftColor = "transparent";
                btn.style.fontWeight = "500";
            });

            // 2. Clicked button ko active class aur styling dein
            button.classList.add("active");
            button.style.background = "#0f172a";
            button.style.fontWeight = "600";

            // 3. Pehle dono views ko hide karein (display none)
            document.getElementById("stock-view").style.display = "none";
            document.getElementById("khata-view").style.display = "none";

            // 4. Target module ko check karke use show karein aur uska exact theme color set karein
            const targetAction = button.innerText.trim();
            
            if (targetAction.includes("Stock Inventory")) {
                const stockView = document.getElementById("stock-view");
                stockView.style.display = "flex";
                
                // Stock ke liye blue theme indicator
                button.style.color = "#3b82f6";
                button.style.borderLeft = "4px solid #3b82f6";
            } else if (targetAction.includes("Khata Ledger")) {
                const khataView = document.getElementById("khata-view");
                khataView.style.display = "flex";
                
                // Khata ke liye green theme indicator
                button.style.color = "#10b981";
                button.style.borderLeft = "4px solid #10b981";
            }
            
            
        });
    });
});